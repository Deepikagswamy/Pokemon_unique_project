export { default as PokemonComponent } from "./pokemon/Pokemon";
export { default as PokemonListComponent } from "./pokemon/PokemonList";
export { default as PokemonDetailComponent } from "./pokemon/PokemonDetail";
