export default {
  colorPrimary: "#FFFFFF",
  colorSecondary: "#F5F5F5",
  
  colorPrimaryDark: "#0077FF",
  colorSecondaryDark: "#CDE1F8",
  
  colorGrey: '#616161',
  colorGrayLight: '#bdbdbd',
  colorOverlay: 'rgba(0, 0, 0, 0.7)'
};
